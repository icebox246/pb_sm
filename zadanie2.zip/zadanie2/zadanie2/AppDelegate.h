//
//  AppDelegate.h
//  zadanie2
//
//  Created by Adam on 10/10/2024.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

