//
//  ViewController.h
//  zadanie2
//
//  Created by Adam on 10/10/2024.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *informationButton;
@property (weak, nonatomic) IBOutlet UIImageView *image;

@end

