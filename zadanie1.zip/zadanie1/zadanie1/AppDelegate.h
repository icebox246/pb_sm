//
//  AppDelegate.h
//  zadanie1
//
//  Created by Adam on 05/10/2024.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

