//
//  SceneDelegate.h
//  zadanie1
//
//  Created by Adam on 05/10/2024.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

